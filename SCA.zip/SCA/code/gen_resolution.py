"""gen_resolution.py -- angular resolution (Fig. resolution, resolution.json).
Two mixing columns a controllable gap apart (third far away), dilated and
clustered at 25 dB with eps = 0.02: reliably resolved for gaps >= 3 deg."""
import json, os, numpy as np
import matplotlib as mpl; mpl.use("Agg"); import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
import ubss_dilation as u

FIG = os.path.join(os.path.dirname(__file__), "..", "figures")
RES = os.path.join(os.path.dirname(__file__), "..", "results")
os.makedirs(FIG, exist_ok=True); os.makedirs(RES, exist_ok=True)
plt.rcParams.update({"font.family": "serif", "font.size": 9, "axes.titlesize": 9,
    "axes.labelsize": 9, "legend.fontsize": 8, "xtick.labelsize": 8,
    "ytick.labelsize": 8, "axes.linewidth": 0.6, "figure.dpi": 150,
    "savefig.bbox": "tight"})

rng = np.random.default_rng(3)
FR = np.array([[100, 220, 50], [10, 130, 170], [160, 190, 80]], float)
ph = rng.uniform(0, 2 * np.pi, size=(3, 3))
amp = np.array([[1, .6, .8], [1, .7, .5], [.9, .6, 1.]])
s, _ = u.generate_sources(FR, n=10000, fs=1000.0, phases=ph, amps=amp)


def dbn(Xd, eps, minpts=5):
    th, _, _ = u.ssp_angles(Xd, energy_frac=0.06, parallel_thr=0.995)
    if th.size == 0:
        return 0, None
    P = np.vstack([np.cos(th), np.sin(th)]).T
    lab = DBSCAN(eps=eps, min_samples=minpts).fit_predict(P)
    ang = np.sort([np.arctan2(np.mean(np.sin(th[lab == l])), np.mean(np.cos(th[lab == l])))
                   for l in set(lab) if l != -1])
    return len(ang), (np.degrees(ang) if len(ang) else None)


gaps = [1, 2, 3, 5, 8, 12, 20]
res = {"gap": gaps, "succ": [], "rmse": []}
for g in gaps:
    base = 30.0
    angs = np.deg2rad([base, base + g, 70.0])
    A = np.vstack([np.cos(angs), np.sin(angs)])
    truth = np.sort(np.degrees(angs))
    sc = 0; rm = []
    for tr in range(50):
        xn = u.mix(s, A, snr_db=25, seed=50000 + tr)
        Xd = u.dilate(u.to_spectrum(xn), 9)
        n, ang = dbn(Xd, eps=0.02)
        if n == 3:
            e = np.sqrt(np.mean((np.sort(ang) - truth) ** 2))
            if e < 2:
                sc += 1; rm.append(e)
    res["succ"].append(100 * sc / 50)
    res["rmse"].append(float(np.mean(rm)) if rm else float("nan"))
    print(f"gap={g:2d}deg: succ {100*sc/50:5.0f}%  rmse {res['rmse'][-1]:.3f}")
json.dump(res, open(os.path.join(RES, "resolution.json"), "w"), indent=2)

fig, ax = plt.subplots(figsize=(3.6, 2.7))
ax.plot(gaps, res["succ"], "s-", color="#c1121f")
ax.set_xlabel("Angular gap between two columns (deg)")
ax.set_ylabel("Correct-detection rate (%)")
ax.set_title(r"Angular resolution (dilation, $\varepsilon=0.02$)")
ax.set_ylim(-5, 105); ax.grid(alpha=0.3)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig_resolution.pdf")); plt.close(fig)
print("saved fig_resolution.pdf")
