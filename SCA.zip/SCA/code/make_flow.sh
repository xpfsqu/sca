#!/usr/bin/env bash
# make_flow.sh -- build the pipeline diagram fig_flow.pdf (Fig. 1) from TikZ.
# Requires a LaTeX installation (pdflatex). Output goes to ../figures/fig_flow.pdf
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
OUT="$DIR/../figures"
mkdir -p "$OUT"
TMP="$(mktemp -d)"
cat > "$TMP/flow.tex" <<'EOF'
\documentclass[border=2pt]{standalone}
\usepackage{tikz}
\usepackage{amsmath}
\usetikzlibrary{arrows.meta,positioning,shapes.geometric,calc}
\newcommand{\bx}{\mathbf{x}}
\newcommand{\bs}{\mathbf{s}}
\newcommand{\bA}{\mathbf{A}}
\newcommand{\Dw}{\mathcal{D}_{w}}
\newcommand{\Ew}{\mathcal{E}_{w}}
\begin{document}
\begin{tikzpicture}[
   node distance=5mm and 8mm,
   box/.style={draw,rounded corners=2pt,align=center,font=\footnotesize,
               minimum height=9mm,inner sep=3pt,fill=blue!4},
   dbox/.style={draw,dashed,rounded corners=2pt,align=center,font=\footnotesize,
               minimum height=9mm,inner sep=3pt,fill=red!4},
   >={Stealth[length=2.4mm]}]
 \node[box] (obs) {Two-channel\\ obs.\ $\bx(t)$};
 \node[box,right=of obs] (tf) {Transform\\ $\Phi$};
 \node[dbox,right=of tf] (dil) {Dilation $\Dw$\\ (populate SSPs)};
 \node[box,right=of dil] (est) {SSP + density\\ clustering:\\ est.\ $\bA$, $n$};
 \node[box,below=8mm of est] (rec) {$\ell_1$ source\\ recovery};
 \node[dbox,left=of rec] (ero) {Erosion $\Ew$\\ (restore atoms)};
 \node[box,left=of ero] (inv) {Inverse\\ $\Phi^{-1}$};
 \node[box,left=of inv] (out) {Sources\\ $\hat\bs(t)$};
 \draw[->] (obs)--(tf); \draw[->] (tf)--(dil); \draw[->] (dil)--(est);
 \draw[->] (est)--(rec); \draw[->] (rec)--(ero); \draw[->] (ero)--(inv);
 \draw[->] (inv)--(out);
\end{tikzpicture}
\end{document}
EOF
( cd "$TMP" && pdflatex -interaction=nonstopmode flow.tex >/dev/null 2>&1 )
cp "$TMP/flow.pdf" "$OUT/fig_flow.pdf"
rm -rf "$TMP"
echo "wrote $OUT/fig_flow.pdf"
