"""Realistic machinery-signal validation: gear harmonics + AM sidebands,
a bearing outer-race impulse train exciting a resonance, and shaft unbalance,
mixed 2x3 (sensor-deficient). Demonstrates DE-SCA on non-tonal signals."""
import json, os, numpy as np
import matplotlib as mpl; mpl.use("Agg"); import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
import ubss_dilation as u

FIG = os.path.join(os.path.dirname(__file__), "..", "figures")
RES = os.path.join(os.path.dirname(__file__), "..", "results")
plt.rcParams.update({"font.family": "serif", "font.size": 9, "axes.titlesize": 9,
    "axes.labelsize": 9, "legend.fontsize": 8, "xtick.labelsize": 8,
    "ytick.labelsize": 8, "lines.linewidth": 1.0, "axes.linewidth": 0.6,
    "figure.dpi": 150, "savefig.bbox": "tight"})
C = {"src": "#1f4e79", "mix": "#b5651d", "rec": "#c1121f"}

FS, N = 2000.0, 10000
t = np.arange(N) / FS
W = 11


def make_sources(seed=0):
    rng = np.random.default_rng(seed)
    # (1) gear mesh: harmonics of 150 Hz, amplitude-modulated at shaft 25 Hz
    fg, fr = 150.0, 25.0
    g = np.zeros(N)
    for k, a in zip([1, 2, 3, 4], [1.0, 0.6, 0.4, 0.25]):
        g += a * np.cos(2 * np.pi * k * fg * t + rng.uniform(0, 2 * np.pi))
    g *= (1 + 0.6 * np.cos(2 * np.pi * fr * t))
    # (2) bearing outer-race: impulse train at 64 Hz exciting a 550 Hz resonance
    fb, fres, zeta = 64.0, 550.0, 0.02
    b = np.zeros(N)
    k = 0
    while k / fb < t[-1]:
        tt = t - k / fb
        m = tt >= 0
        b[m] += np.exp(-2 * np.pi * zeta * fres * tt[m]) * np.cos(2 * np.pi * fres * tt[m])
        k += 1
    b = b / np.max(np.abs(b)) * 1.2
    # (3) shaft unbalance: 30 Hz fundamental + harmonics
    f0 = 30.0
    ub = (1.0 * np.cos(2 * np.pi * f0 * t + rng.uniform(0, 2 * np.pi))
          + 0.3 * np.cos(2 * np.pi * 2 * f0 * t)
          + 0.15 * np.cos(2 * np.pi * 3 * f0 * t))
    s = np.vstack([g, b, ub])
    return s / np.std(s, axis=1, keepdims=True)


def dbscan_cols(Xd, mp=5, eps=0.04, ef=0.03, pth=0.985):
    th, _, _ = u.ssp_angles(Xd, energy_frac=ef, parallel_thr=pth)
    if th.size == 0:
        return np.zeros((2, 0)), 0, 0
    P = np.vstack([np.cos(th), np.sin(th)]).T
    lab = DBSCAN(eps=eps, min_samples=mp).fit_predict(P)
    ang = np.sort([np.arctan2(np.mean(np.sin(th[lab == l])), np.mean(np.cos(th[lab == l])))
                   for l in set(lab) if l != -1])
    return (np.vstack([np.cos(ang), np.sin(ang)]) if len(ang) else np.zeros((2, 0))), len(ang), th.size


A = u.DEFAULT_A
truth = np.sort(np.degrees(np.arctan2(A[1], A[0])))
s = make_sources(0)

out = {"snr": [], "succ_nodil": [], "succ_dil": [], "Aerr": [], "corr": []}
REPS = 30
for snr in [30, 25, 20]:
    s0 = s1 = 0; rm = []; cc = []
    for tr in range(REPS):
        x = u.mix(s, A, snr_db=snr, seed=tr)
        X = u.to_spectrum(x)
        c0, n0, _ = dbscan_cols(X)
        c1, n1, _ = dbscan_cols(u.dilate(X, W))
        s0 += (n0 == 3); s1 += (n1 == 3)
        if n1 == 3:
            rm.append(np.sqrt(np.mean((np.sort(np.degrees(np.arctan2(c1[1], c1[0]))) - truth) ** 2)))
            S = u.recover_sources(X, c1, energy_frac=0.01)
            rec = u.from_spectrum(S)
            mc, _, _, _ = u.match_and_score(s, rec); cc.append(mc)
    out["snr"].append(snr)
    out["succ_nodil"].append(round(100 * s0 / REPS))
    out["succ_dil"].append(round(100 * s1 / REPS))
    out["Aerr"].append(float(np.mean(rm)) if rm else float("nan"))
    out["corr"].append(float(np.mean(cc)) if cc else float("nan"))
    print(f"SNR{snr}: nodil {out['succ_nodil'][-1]}%  dil {out['succ_dil'][-1]}%  "
          f"Aerr {out['Aerr'][-1]:.3f}  corr {out['corr'][-1]:.4f}")
json.dump(out, open(os.path.join(RES, "realistic.json"), "w"), indent=2)

# figure: one realistic case at 25 dB -- spectra + recovered overlay
seed_fig = None
for sd in range(50):
    xx = u.mix(s, A, snr_db=25, seed=sd)
    cc_, nn_, _ = dbscan_cols(u.dilate(u.to_spectrum(xx), W))
    if nn_ == 3:
        seed_fig = sd; break
x = u.mix(s, A, snr_db=25, seed=seed_fig)
X = u.to_spectrum(x)
cols, n, _ = dbscan_cols(u.dilate(X, W))
S = u.recover_sources(X, cols, energy_frac=0.01)
rec = u.from_spectrum(S)
mc, per, perm, _ = u.match_and_score(s, rec)
freq = np.arange(N) / N * FS
fm = freq <= 700
fig, ax = plt.subplots(2, 3, figsize=(7.0, 3.6))
names = ["Gear mesh (+ sidebands)", "Bearing impulses", "Shaft unbalance"]
for i in range(3):
    ax[0, i].plot(freq[fm], np.abs(u.to_spectrum(s)[i][fm]) * 2 / N, color=C["src"])
    ax[0, i].set_title(names[i]); ax[0, i].set_xlim(0, 700)
    if i == 0: ax[0, i].set_ylabel("Source |S(f)|")
    j = perm[i]; a = rec[j]; al = np.dot(s[i], a) / (np.dot(a, a) + 1e-30)
    seg = slice(0, 500)
    ax[1, i].plot(t[seg], s[i][seg], color=C["src"], label="true")
    ax[1, i].plot(t[seg], (al * a)[seg], color=C["rec"], ls="--", label="recovered")
    ax[1, i].set_xlabel("Time (s)")
    if i == 0: ax[1, i].set_ylabel("Amplitude"); ax[1, i].legend(fontsize=7)
fig.suptitle(f"Realistic machinery signals: 3 sources from 2 sensors, 25 dB "
             f"(mean corr {mc:.3f})", fontsize=9)
fig.tight_layout(rect=[0, 0, 1, 0.96])
fig.savefig(os.path.join(FIG, "fig_realistic.pdf")); plt.close(fig)
print("figure saved; per-source corr", np.round(per, 4))
