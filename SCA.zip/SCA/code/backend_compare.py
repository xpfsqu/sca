import numpy as np, ubss_dilation as u, json
from sklearn.cluster import DBSCAN, KMeans
rng = np.random.default_rng(7); ph = rng.uniform(0, 2*np.pi, size=(3,3))
AMPS = np.array([[1.0,0.55,0.80],[1.0,0.65,0.45],[0.90,0.60,1.0]])
s, t = u.generate_sources(n=10000, fs=1000.0, amps=AMPS, phases=ph); A = u.DEFAULT_A
truth = np.sort(np.degrees(np.arctan2(A[1], A[0])))

def get_ssp(X):
    th, _, _ = u.ssp_angles(X, energy_frac=0.06, parallel_thr=0.995); return th

def eval_cols(ang):
    ang = np.sort(np.degrees(ang))
    if ang.size != 3: return None
    return np.sqrt(np.mean((ang - truth)**2))

def run(method, dil, reps=60):
    succ = 0; rmse = []
    for tr in range(reps):
        xn = u.mix(s, A, snr_db=20, seed=15000+tr); X = u.to_spectrum(xn)
        if dil: X = u.dilate(X, 9)
        th = get_ssp(X)
        if th.size < 3: continue
        P = np.vstack([np.cos(th), np.sin(th)]).T
        if method == 'kmeans1':
            km = KMeans(3, n_init=1, init='random', random_state=tr).fit(P)
            ang = np.arctan2(km.cluster_centers_[:,1], km.cluster_centers_[:,0])
        elif method == 'kmeans10':
            km = KMeans(3, n_init=10, random_state=tr).fit(P)
            ang = np.arctan2(km.cluster_centers_[:,1], km.cluster_centers_[:,0])
        elif method == 'dbscan':
            lab = DBSCAN(eps=0.03, min_samples=5).fit_predict(P)
            ids = [l for l in set(lab) if l != -1]
            if len(ids) != 3: continue
            ang = np.array([np.arctan2(np.mean(np.sin(th[lab==l])), np.mean(np.cos(th[lab==l]))) for l in ids])
        r = eval_cols(np.array(ang))
        if r is not None and r < 2.0:
            succ += 1; rmse.append(r)
    return 100*succ/reps, (float(np.mean(rmse)) if rmse else float('nan'))

res = {}
for m in ['kmeans1', 'kmeans10', 'dbscan']:
    for d in [False, True]:
        key = f'{m}_{"dil" if d else "nodil"}'
        res[key] = run(m, d)
        print(f'{m:9s} {("dil" if d else "nodil"):5s}: succ={res[key][0]:5.0f}%  rmse={res[key][1]:.3f}')
json.dump(res, open('../results/backend_compare.json', 'w'), indent=2)
