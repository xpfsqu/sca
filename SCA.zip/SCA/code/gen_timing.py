"""gen_timing.py -- end-to-end runtime versus record length (Fig. timing,
timing.json). Confirms the O(m N log N) scaling and sub-second runtime."""
import json, os, time, numpy as np
import matplotlib as mpl; mpl.use("Agg"); import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
import ubss_dilation as u

FIG = os.path.join(os.path.dirname(__file__), "..", "figures")
RES = os.path.join(os.path.dirname(__file__), "..", "results")
os.makedirs(FIG, exist_ok=True); os.makedirs(RES, exist_ok=True)
plt.rcParams.update({"font.family": "serif", "font.size": 9, "axes.titlesize": 9,
    "axes.labelsize": 9, "legend.fontsize": 8, "xtick.labelsize": 8,
    "ytick.labelsize": 8, "axes.linewidth": 0.6, "figure.dpi": 150,
    "savefig.bbox": "tight"})

rng = np.random.default_rng(7)
ph = rng.uniform(0, 2 * np.pi, size=(3, 3))
AMPS = np.array([[1.0, 0.55, 0.80], [1.0, 0.65, 0.45], [0.90, 0.60, 1.0]])
A = u.DEFAULT_A


def full(Xn, w):
    Xd = u.dilate(Xn, w)
    th, _, _ = u.ssp_angles(Xd, energy_frac=0.06, parallel_thr=0.995)
    P = np.vstack([np.cos(th), np.sin(th)]).T
    lab = DBSCAN(eps=0.03, min_samples=5).fit_predict(P)
    ang = np.sort([np.arctan2(np.mean(np.sin(th[lab == l])), np.mean(np.cos(th[lab == l])))
                   for l in set(lab) if l != -1])
    cols = np.vstack([np.cos(ang), np.sin(ang)])
    if cols.shape[1] != 3:
        return
    Sd = u.recover_sources(Xd, cols, energy_frac=0.02)
    u.from_spectrum(u.erode(Sd, w))


res = {"N": [], "t": []}
for N in [2000, 5000, 10000, 20000, 40000]:
    s, _ = u.generate_sources(n=N, fs=1000.0, amps=AMPS, phases=ph)
    xn = u.mix(s, A, snr_db=30, seed=1)
    Xn = u.to_spectrum(xn)
    full(Xn, 9)  # warm-up
    ts = []
    for _ in range(3):
        t0 = time.perf_counter(); full(Xn, 9); ts.append(time.perf_counter() - t0)
    res["N"].append(N); res["t"].append(float(np.median(ts)))
    print(f"N={N:6d}: {np.median(ts)*1000:7.1f} ms")
json.dump(res, open(os.path.join(RES, "timing.json"), "w"), indent=2)

fig, ax = plt.subplots(figsize=(3.5, 2.6))
ax.plot(res["N"], np.array(res["t"]) * 1000, "o-", color="#1f4e79")
ax.set_xlabel("Record length $N$ (samples)"); ax.set_ylabel("Runtime (ms)")
ax.set_title("End-to-end runtime"); ax.grid(alpha=0.3)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig_timing.pdf")); plt.close(fig)
print("saved fig_timing.pdf")
