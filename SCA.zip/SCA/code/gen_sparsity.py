"""gen_sparsity.py -- robustness to representation sparsity (Fig. sparsity_sweep,
sparsity_sweep.json). Reproduces the L (atoms-per-source) sweep at 25 dB with
minPts = 5: without dilation the detection rate is 0% for L < minPts and jumps to
100% at L = 5; with dilation it is 100% from L = 2."""
import json, os, numpy as np
import matplotlib as mpl; mpl.use("Agg"); import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
import ubss_dilation as u

FIG = os.path.join(os.path.dirname(__file__), "..", "figures")
RES = os.path.join(os.path.dirname(__file__), "..", "results")
os.makedirs(FIG, exist_ok=True); os.makedirs(RES, exist_ok=True)
plt.rcParams.update({"font.family": "serif", "font.size": 9, "axes.titlesize": 9,
    "axes.labelsize": 9, "legend.fontsize": 8, "xtick.labelsize": 8,
    "ytick.labelsize": 8, "axes.linewidth": 0.6, "figure.dpi": 150,
    "savefig.bbox": "tight"})

rng = np.random.default_rng(11)
base = np.array([[100, 220, 50, 150, 205, 33],
                 [10, 130, 170, 90, 245, 60],
                 [160, 190, 80, 120, 30, 210]], float)
ang = np.deg2rad([58.0, 16.0, 63.4])
A = np.vstack([np.cos(ang), np.sin(ang)])


def dbscan_n(Xd, minpts=5, eps=0.03):
    th, _, _ = u.ssp_angles(Xd, energy_frac=0.06, parallel_thr=0.995)
    if th.size == 0:
        return 0, 0
    P = np.vstack([np.cos(th), np.sin(th)]).T
    lab = DBSCAN(eps=eps, min_samples=minpts).fit_predict(P)
    return len(set(lab) - {-1}), th.size


Ls = [1, 2, 3, 4, 5, 6]
res = {"L": Ls, "succ_nodil": [], "succ_dil": [], "npts_nodil": [], "npts_dil": []}
for L in Ls:
    fr = base[:, :L]
    s, _ = u.generate_sources(fr, n=10000, fs=1000.0,
                              phases=rng.uniform(0, 2 * np.pi, size=(3, L)),
                              amps=0.5 + rng.random((3, L)))
    s0 = s1 = 0; n0 = []; n1 = []
    for tr in range(50):
        xn = u.mix(s, A, snr_db=25, seed=40000 + tr)
        Xn = u.to_spectrum(xn)
        c0, p0 = dbscan_n(Xn)
        c1, p1 = dbscan_n(u.dilate(Xn, 9))
        s0 += (c0 == 3); s1 += (c1 == 3); n0.append(p0); n1.append(p1)
    res["succ_nodil"].append(100 * s0 / 50); res["succ_dil"].append(100 * s1 / 50)
    res["npts_nodil"].append(float(np.mean(n0))); res["npts_dil"].append(float(np.mean(n1)))
    print(f"L={L}: nodil {100*s0/50:5.0f}% ({np.mean(n0):.0f} pts) | "
          f"dil {100*s1/50:5.0f}% ({np.mean(n1):.0f} pts)")
json.dump(res, open(os.path.join(RES, "sparsity_sweep.json"), "w"), indent=2)

fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.7))
ax[0].plot(Ls, res["succ_nodil"], "o-", color="#6c757d", label="without dilation")
ax[0].plot(Ls, res["succ_dil"], "s-", color="#c1121f", label="with dilation ($w=9$)")
ax[0].axvline(5, color="k", ls=":", lw=0.7); ax[0].text(5.05, 50, "minPts", fontsize=7)
ax[0].set_xlabel("Atoms per source $L$"); ax[0].set_ylabel("Correct-detection rate (%)")
ax[0].set_title("Success vs representation sparsity"); ax[0].set_ylim(-5, 105); ax[0].legend()
ax[1].plot(Ls, res["npts_nodil"], "o-", color="#6c757d", label="without dilation")
ax[1].plot(Ls, res["npts_dil"], "s-", color="#c1121f", label="with dilation")
ax[1].axhline(5, color="k", ls=":", lw=0.7); ax[1].text(1, 7, "minPts$=5$", fontsize=7)
ax[1].set_xlabel("Atoms per source $L$"); ax[1].set_ylabel("SSPs per direction")
ax[1].set_yscale("log"); ax[1].set_title("SSP supply vs sparsity"); ax[1].legend()
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig_sparsity_sweep.pdf")); plt.close(fig)
print("saved fig_sparsity_sweep.pdf")
