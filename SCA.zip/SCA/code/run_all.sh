#!/usr/bin/env bash
# run_all.sh -- reproduce every figure and numerical result in the paper.
set -e
cd "$(dirname "$0")"
echo "[1/9] main benchmark ..........";  python3 run_experiments.py
echo "[2/9] back-end comparison ......";  python3 backend_compare.py
echo "[3/9] extra figures ............";  python3 gen_extra.py
echo "[4/9] realistic signals ........";  python3 gen_realistic.py
echo "[5/9] sparsity sweep ...........";  python3 gen_sparsity.py
echo "[6/9] angular resolution .......";  python3 gen_resolution.py
echo "[7/9] parameter sensitivity ....";  python3 gen_paramsens.py
echo "[8/9] runtime scaling ..........";  python3 gen_timing.py
echo "[9/9] pipeline diagram .........";  bash make_flow.sh || echo "  (skipped: pdflatex not found)"
echo "Done. Figures in ../figures, numeric results in ../results."
