"""
ubss_dilation.py
================
Core routines for the dilation-erosion sparse-component-analysis (DE-SCA)
framework for underdetermined blind source separation (UBSS) of non-sparse
rotating-machinery vibration signals under sensor deficiency.

The module implements, in a self-contained way:

  * signal generation for the multi-tone rotating-machinery model,
  * the sparsifying (DFT) transform,
  * the moving-average DILATION operator D_w (a normalised box filter),
  * its exact inverse EROSION operator E_w for isolated spectral lines,
  * amplitude-based single-source-point (SSP) screening,
  * mixing-matrix estimation by angular histogram + K-means refinement,
  * l1 / basis-pursuit source recovery for the 2-observation case,
  * evaluation metrics (mixing-matrix angular error, correlation, SDR).

Author: Yinjie Jia, Pengfei Xu (Suqian University)
License: MIT
"""

from __future__ import annotations

import numpy as np
from numpy.fft import fft, ifft
from scipy.optimize import linprog

# ----------------------------------------------------------------------------
# 1. Signal model
# ----------------------------------------------------------------------------

DEFAULT_FREQS = np.array(
    [
        [100.0, 220.0, 50.0],   # source 1 (three tones)
        [10.0, 130.0, 170.0],   # source 2
        [160.0, 190.0, 80.0],   # source 3
    ]
)

DEFAULT_A = np.array([[0.5, 0.7, 0.3],
                      [0.8, 0.2, 0.6]])


def generate_sources(freqs=DEFAULT_FREQS, n=10000, fs=1000.0, amps=None,
                     phases=None, seed=None):
    """Generate the multi-tone rotating-machinery sources.

    Each source is a sum of pure cosines and is therefore *dense* (non-sparse)
    in the time domain but *sparse* (a few spectral lines) in the DFT domain.

    Returns
    -------
    s : (n_src, n) ndarray  - the source matrix S
    t : (n,) ndarray        - time vector
    """
    rng = np.random.default_rng(seed)
    freqs = np.asarray(freqs, dtype=float)
    n_src, n_tone = freqs.shape
    t = np.arange(n) / fs
    if amps is None:
        amps = np.ones((n_src, n_tone))
    if phases is None:
        phases = np.zeros((n_src, n_tone))
    s = np.zeros((n_src, n))
    for i in range(n_src):
        for k in range(n_tone):
            s[i] += amps[i, k] * np.cos(2 * np.pi * freqs[i, k] * t
                                        + phases[i, k])
    return s, t


def mix(s, A, snr_db=None, seed=None):
    """Instantaneous linear mixing  x = A s  with optional AWGN at ``snr_db``."""
    x = A @ s
    if snr_db is not None:
        rng = np.random.default_rng(seed)
        for r in range(x.shape[0]):
            p_sig = np.mean(x[r] ** 2)
            p_noise = p_sig / (10 ** (snr_db / 10.0))
            x[r] = x[r] + rng.normal(0.0, np.sqrt(p_noise), size=x.shape[1])
    return x


# ----------------------------------------------------------------------------
# 2. Sparsifying transform
# ----------------------------------------------------------------------------

def to_spectrum(x):
    """Row-wise DFT of the observation matrix (returns complex spectra)."""
    return np.vstack([fft(x[r]) for r in range(x.shape[0])])


def from_spectrum(X):
    """Row-wise inverse DFT (returns the real part)."""
    return np.vstack([np.real(ifft(X[r])) for r in range(X.shape[0])])


# ----------------------------------------------------------------------------
# 3. Morphological-style dilation / erosion on the sparse domain
# ----------------------------------------------------------------------------

def _box_kernel(w):
    if w % 2 == 0:
        raise ValueError("window length w must be odd")
    return np.ones(w) / w


def dilate(X, w):
    """Moving-average DILATION D_w applied row-wise.

    ``D_w`` is the normalised box filter of odd length ``w`` (centred,
    'same' length).  Because the same linear operator is applied to *every*
    observation channel, and D_w commutes with the constant mixing matrix,
    the dilated observations remain mixtures of the *dilated sources* through
    the *identical* mixing matrix A:  D_w{X} = A * D_w{S}.  The isolated
    spectral lines are broadened into short plateaux, which multiplies the
    number of single-source points available for mixing-matrix estimation.
    """
    if w == 1:
        return X.copy()
    h = _box_kernel(w)
    out = np.empty_like(X)
    for r in range(X.shape[0]):
        re = np.convolve(np.real(X[r]), h, mode="same")
        im = np.convolve(np.imag(X[r]), h, mode="same")
        out[r] = re + 1j * im
    return out


def _erode_1d(y, w):
    """Exact inverse of the centred moving average for isolated-line signals.

    A centred moving average of odd width w = 2m+1 obeys

        y[n] = (1/w) * sum_{k=-m}^{m} x[n+k],

    hence the running recurrence

        x[n+m+1] = x[n-m] + w * (y[n+1] - y[n]).

    Because the line spectrum is zero on the long runs between spectral
    lines, the recurrence can be *anchored* on those zero runs, so no error
    accumulates across lines and the spikes are recovered exactly.  This is
    the "tightening" (erosion) operator E_w that undoes D_w.
    """
    y = np.asarray(y, dtype=float)
    L = y.size
    m = (w - 1) // 2
    x = np.zeros(L)
    # a sample is "anchored to zero" if the whole dilation support that could
    # feed it lies in a region where y is (numerically) zero.
    tol = 1e-9 * (np.max(np.abs(y)) + 1e-30)
    zero = np.abs(y) <= tol
    # cumulative "recent zero run" length
    for n in range(L):
        # index we are about to determine: p = n + m + 1
        p = n + m + 1
        if p >= L:
            break
        # anchor: if y is zero over a full window around p, force x[p]=0
        lo = max(0, p - w)
        hi = min(L, p + 1)
        if np.all(zero[lo:hi]):
            x[p] = 0.0
            continue
        x_nm = x[n - m] if (n - m) >= 0 else 0.0
        x[p] = x_nm + w * (y[n + 1] - y[n])
    # first m+1 samples: fill from the leading zero region (already zeros)
    return x


def erode(X, w):
    """Row-wise EROSION E_w = D_w^{-1} (applied to real and imaginary parts)."""
    if w == 1:
        return X.copy()
    out = np.empty_like(X)
    for r in range(X.shape[0]):
        re = _erode_1d(np.real(X[r]), w)
        im = _erode_1d(np.imag(X[r]), w)
        out[r] = re + 1j * im
    return out


# ----------------------------------------------------------------------------
# 4. Single-source-point screening and mixing-matrix estimation
# ----------------------------------------------------------------------------

def ssp_angles(X, energy_frac=1e-2, parallel_thr=0.95, half_spectrum=True):
    """Return mixing angles at detected single-source points (SSPs).

    A robust SSP detector (Reju et al., 2009) is used: at a single-source
    point k the observation vector x(k) = a_j S_j(k) has real part
    Re[x(k)] = a_j Re[S_j(k)] and imaginary part Im[x(k)] = a_j Im[S_j(k)]
    that are *parallel* (both proportional to the real column a_j).  Bins for
    which the two parts are nearly collinear,

        |<Re x, Im x>| / (||Re x|| ||Im x||) >= parallel_thr,

    are kept as SSPs; multi-source bins and (dilated) noise bins fail the test
    and are rejected.  The surviving direction is a_j = Re[x(k)]/||Re[x(k)]||,
    mapped to the first quadrant, and the angle theta = atan2(a2j, a1j).
    """
    X1, X2 = X[0], X[1]
    N = X1.size
    idx = np.arange(1, N // 2) if half_spectrum else np.arange(N)
    mag = np.sqrt(np.abs(X1) ** 2 + np.abs(X2) ** 2)
    amp_gate = idx[mag[idx] > energy_frac * mag.max()]
    Re = np.vstack([np.real(X1[amp_gate]), np.real(X2[amp_gate])])
    Im = np.vstack([np.imag(X1[amp_gate]), np.imag(X2[amp_gate])])
    nRe = np.linalg.norm(Re, axis=0)
    nIm = np.linalg.norm(Im, axis=0)
    good = (nRe > 1e-12) & (nIm > 1e-12)
    cosang = np.zeros(amp_gate.size)
    cosang[good] = np.abs(np.sum(Re[:, good] * Im[:, good], axis=0)
                          / (nRe[good] * nIm[good]))
    keep_mask = cosang >= parallel_thr
    keep = amp_gate[keep_mask]
    # direction from the (larger-norm) real part; fall back to magnitudes
    a1 = np.abs(X1[keep])
    a2 = np.abs(X2[keep])
    theta = np.arctan2(a2, a1)          # in [0, pi/2] for positive columns
    return theta, mag[keep], keep


def estimate_mixing(X, n_src, energy_frac=1e-2, parallel_thr=0.95,
                    n_bins=180, refine=True):
    """Estimate the (2 x n_src) mixing matrix from a (dilated) spectrum.

    Steps: (i) SSP detection, (ii) angular histogram peak picking to seed
    ``n_src`` directions, (iii) optional 1-D K-means refinement of the angles.
    Columns are returned as unit vectors [cos theta; sin theta].
    """
    theta, weight, _ = ssp_angles(X, energy_frac=energy_frac,
                                  parallel_thr=parallel_thr)
    if theta.size < n_src:
        raise RuntimeError("too few single-source points to estimate mixing")
    # weighted histogram over [0, pi/2]
    hist, edges = np.histogram(theta, bins=n_bins, range=(0, np.pi / 2),
                               weights=weight)
    centers = 0.5 * (edges[:-1] + edges[1:])
    # pick n_src strongest, well-separated histogram peaks
    order = np.argsort(hist)[::-1]
    peaks = []
    min_sep = (np.pi / 2) / n_bins * 3
    for o in order:
        c = centers[o]
        if hist[o] <= 0:
            continue
        if all(abs(c - p) > min_sep for p in peaks):
            peaks.append(c)
        if len(peaks) == n_src:
            break
    peaks = np.sort(np.array(peaks))
    if refine and peaks.size == n_src:
        peaks = _kmeans_1d(theta, peaks, weight, iters=50)
    cols = np.vstack([np.cos(peaks), np.sin(peaks)])
    return cols, peaks, theta, weight


def estimate_mixing_kmeans(X, n_src, energy_frac=1e-2, parallel_thr=0.95,
                           n_init=1, seed=0):
    """Mixing-matrix estimation by K-means on the unit-half-circle scatter.

    This mirrors the *standard* SCA pipeline (SSP detection followed by
    clustering).  With ``n_init=1`` and a random initialisation it reproduces
    the instability reported for over-sparse representations: on very few
    isolated points, random seeds frequently collapse two nearby directions
    into one cluster.  Broadening the lines by dilation multiplies the number
    of SSPs and makes the clustering reliable.
    """
    theta, weight, _ = ssp_angles(X, energy_frac=energy_frac,
                                  parallel_thr=parallel_thr)
    if theta.size < n_src:
        raise RuntimeError("too few single-source points to estimate mixing")
    pts = theta                                   # cluster in angle space
    rng = np.random.default_rng(seed)
    best_c, best_j = None, np.inf
    for _ in range(max(1, n_init)):
        c0 = rng.choice(pts, size=n_src, replace=False)
        c = _kmeans_1d(pts, np.sort(c0), weight, iters=100)
        d = np.min(np.abs(pts[:, None] - c[None, :]), axis=1)
        J = np.sum(weight * d ** 2)
        if J < best_j:
            best_j, best_c = J, c
    peaks = np.sort(best_c)
    cols = np.vstack([np.cos(peaks), np.sin(peaks)])
    return cols, peaks, theta, weight


def _kmeans_1d(theta, centers, weight=None, iters=50):
    centers = np.array(centers, dtype=float)
    if weight is None:
        weight = np.ones_like(theta)
    for _ in range(iters):
        d = np.abs(theta[:, None] - centers[None, :])
        lab = np.argmin(d, axis=1)
        new = centers.copy()
        for j in range(centers.size):
            msk = lab == j
            if np.any(msk):
                new[j] = np.average(theta[msk], weights=weight[msk])
        if np.allclose(new, centers, atol=1e-9):
            centers = new
            break
        centers = new
    return np.sort(centers)


# ----------------------------------------------------------------------------
# 5. l1 source recovery (basis pursuit) for the 2-observation case
# ----------------------------------------------------------------------------

def _l1_min(Ahat, x_re, x_im):
    """min ||s||_1 s.t. Ahat s = x, for complex x via real stacking.

    Complex variables s = sr + i si are recovered by minimising
    sum |s_j| (approximated by the l1 norm of the concatenated real vector),
    subject to the real/imaginary equality constraints.  Solved with linprog.
    """
    n = Ahat.shape[1]
    # variables: [sr(n), si(n), u(n)] with u_j >= |sr_j|,|si_j| surrogate.
    # We use the standard LP relaxation of grouped l1 by bounding an auxiliary
    # t_j >= sqrt(sr^2+si^2) via t_j >= |sr_j|, t_j >= |si_j| (l-inf surrogate).
    # variables order: sr, si, t
    A_eq = np.zeros((4, 3 * n))
    A_eq[0, 0:n] = Ahat[0]
    A_eq[1, 0:n] = Ahat[1]
    A_eq[2, n:2 * n] = Ahat[0]
    A_eq[3, n:2 * n] = Ahat[1]
    b_eq = np.array([x_re[0], x_re[1], x_im[0], x_im[1]])
    # inequalities t>=|sr|, t>=|si|  -> sr - t <=0 ; -sr - t <=0 ; si - t <=0 ; -si - t<=0
    rows = []
    rhs = []
    for j in range(n):
        for sgn in (+1, -1):
            r = np.zeros(3 * n)
            r[j] = sgn
            r[2 * n + j] = -1
            rows.append(r); rhs.append(0.0)
            r2 = np.zeros(3 * n)
            r2[n + j] = sgn
            r2[2 * n + j] = -1
            rows.append(r2); rhs.append(0.0)
    A_ub = np.array(rows)
    b_ub = np.array(rhs)
    c = np.zeros(3 * n)
    c[2 * n:] = 1.0
    bounds = [(None, None)] * (2 * n) + [(0, None)] * n
    res = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq,
                  bounds=bounds, method="highs")
    if not res.success:
        # fall back: least-squares
        sr, *_ = np.linalg.lstsq(Ahat, x_re, rcond=None)
        si, *_ = np.linalg.lstsq(Ahat, x_im, rcond=None)
        return sr + 1j * si
    sr = res.x[0:n]
    si = res.x[n:2 * n]
    return sr + 1j * si


def recover_sources(X, Ahat, energy_frac=1e-3):
    """Recover ``n_src`` source spectra from a 2-channel spectrum via l1.

    Bins whose combined energy is below ``energy_frac`` of the peak are set to
    zero (the sparse support); the remaining bins are solved independently.
    Hermitian symmetry is enforced so the inverse DFT is real.
    """
    n_src = Ahat.shape[1]
    N = X.shape[1]
    S = np.zeros((n_src, N), dtype=complex)
    mag = np.sqrt(np.abs(X[0]) ** 2 + np.abs(X[1]) ** 2)
    thr = energy_frac * mag.max()
    active = np.where(mag > thr)[0]
    for k in active:
        if k == 0 or k > N // 2:
            continue
        s_k = _l1_min(Ahat,
                      np.array([np.real(X[0, k]), np.real(X[1, k])]),
                      np.array([np.imag(X[0, k]), np.imag(X[1, k])]))
        S[:, k] = s_k
        S[:, N - k] = np.conj(s_k)      # Hermitian symmetry
    return S


# ----------------------------------------------------------------------------
# 6. Metrics
# ----------------------------------------------------------------------------

def mixing_angular_error(A_true, cols_hat):
    """Mean angular error (degrees) between true columns and estimates
    after optimal permutation matching.  ``cols_hat`` columns are unit norm.
    """
    n = A_true.shape[1]
    a_true = A_true / np.linalg.norm(A_true, axis=0, keepdims=True)
    th_true = np.arctan2(a_true[1], a_true[0])
    th_hat = np.arctan2(cols_hat[1], cols_hat[0])
    # brute-force permutation (n<=4)
    from itertools import permutations
    best = np.inf
    for p in permutations(range(n)):
        err = np.mean(np.abs(np.degrees(th_true - th_hat[list(p)])))
        best = min(best, err)
    return best


def match_and_score(s_true, s_hat):
    """Permutation/scale/sign-invariant correlation between sources.

    Returns (mean_corr, per_source_corr, permutation, sdr_db).
    """
    from itertools import permutations
    n = s_true.shape[0]

    def corr(a, b):
        a = a - a.mean(); b = b - b.mean()
        d = np.linalg.norm(a) * np.linalg.norm(b)
        return 0.0 if d == 0 else np.abs(np.dot(a, b) / d)

    C = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            C[i, j] = corr(s_true[i], s_hat[j])
    best = None
    for p in permutations(range(n)):
        val = np.mean([C[i, p[i]] for i in range(n)])
        if best is None or val > best[0]:
            best = (val, p)
    mean_corr, perm = best
    per = np.array([C[i, perm[i]] for i in range(n)])
    sdr = []
    for i in range(n):
        h = s_hat[perm[i]]
        alpha = np.dot(s_true[i], h) / (np.dot(h, h) + 1e-30)
        e = s_true[i] - alpha * h
        sdr.append(10 * np.log10(np.sum(s_true[i] ** 2) /
                                 (np.sum(e ** 2) + 1e-30)))
    return mean_corr, per, perm, np.array(sdr)


# ----------------------------------------------------------------------------
# 7. End-to-end convenience wrapper (the paper's DE-SCA pipeline with DBSCAN)
# ----------------------------------------------------------------------------

def estimate_mixing_dbscan(Xd, energy_frac=0.06, parallel_thr=0.995,
                           eps=0.03, min_samples=5):
    """Density-based (DBSCAN) mixing-matrix estimation on a dilated spectrum.

    Returns (cols, n_hat) where ``cols`` is 2 x n_hat with unit columns sorted
    by angle, and ``n_hat`` is the inferred number of sources.
    """
    from sklearn.cluster import DBSCAN
    theta, weight, _ = ssp_angles(Xd, energy_frac=energy_frac,
                                  parallel_thr=parallel_thr)
    if theta.size == 0:
        return np.zeros((2, 0)), 0
    P = np.vstack([np.cos(theta), np.sin(theta)]).T
    lab = DBSCAN(eps=eps, min_samples=min_samples).fit_predict(P)
    ang = []
    for l in sorted(set(lab)):
        if l == -1:
            continue
        m = lab == l
        ang.append(np.arctan2(np.mean(np.sin(theta[m])),
                              np.mean(np.cos(theta[m]))))
    ang = np.sort(ang)
    cols = np.vstack([np.cos(ang), np.sin(ang)]) if len(ang) else np.zeros((2, 0))
    return cols, len(ang)


def separate(x, w=9, eps=0.03, min_samples=5, energy_frac=0.06,
             parallel_thr=0.995, recover_energy_frac=0.02):
    """Full DE-SCA pipeline: transform -> dilate -> DBSCAN estimate ->
    l1 recover -> erode -> inverse transform.

    Parameters
    ----------
    x : (m, N) ndarray - the m observations (m = 2 supported).

    Returns
    -------
    A_hat : (2, n_hat) ndarray - estimated unit mixing columns.
    s_hat : (n_hat, N) ndarray - recovered time-domain sources.
    """
    X = to_spectrum(x)
    Xd = dilate(X, w)
    A_hat, n_hat = estimate_mixing_dbscan(
        Xd, energy_frac=energy_frac, parallel_thr=parallel_thr,
        eps=eps, min_samples=min_samples)
    if n_hat == 0:
        raise RuntimeError("no mixing directions found; try a larger window w")
    Sd = recover_sources(Xd, A_hat, energy_frac=recover_energy_frac)
    Se = erode(Sd, w)
    s_hat = from_spectrum(Se)
    return A_hat, s_hat
