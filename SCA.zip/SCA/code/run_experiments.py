"""
run_experiments.py
==================
Reproduces every figure, table value and numerical result reported in the
manuscript.  All outputs are written to ../figures and ../results.

Run:  python run_experiments.py
"""
import json
import os
import time
import numpy as np
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN

import ubss_dilation as u

# ----------------------------------------------------------------------------
FIG = os.path.join(os.path.dirname(__file__), "..", "figures")
RES = os.path.join(os.path.dirname(__file__), "..", "results")
os.makedirs(FIG, exist_ok=True)
os.makedirs(RES, exist_ok=True)

plt.rcParams.update({
    "font.family": "serif",
    "font.size": 9,
    "axes.titlesize": 9,
    "axes.labelsize": 9,
    "legend.fontsize": 8,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "lines.linewidth": 1.0,
    "axes.linewidth": 0.6,
    "figure.dpi": 150,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.02,
})
C = {"src": "#1f4e79", "mix": "#b5651d", "rec": "#c1121f",
     "a": "#1f4e79", "b": "#2a9d8f", "c": "#e76f51", "grey": "#6c757d"}

# ----------------------------------------------------------------------------
# Common experiment configuration
# ----------------------------------------------------------------------------
FS = 1000.0
N = 10000
A = u.DEFAULT_A                     # 2 x 3 : sensor-deficient (2 sensors, 3 sources)
FREQS = u.DEFAULT_FREQS
RNG_PH = np.random.default_rng(7)
PHASES = RNG_PH.uniform(0, 2 * np.pi, size=FREQS.shape)
# realistic distinct tone amplitudes (fundamental stronger than harmonics)
AMPS = np.array([[1.0, 0.55, 0.80],
                 [1.0, 0.65, 0.45],
                 [0.90, 0.60, 1.0]])
S, T = u.generate_sources(FREQS, n=N, fs=FS, amps=AMPS, phases=PHASES)
TRUE_ANG = np.degrees(np.arctan2(A[1], A[0]))
W = 9                               # default dilation window
results = {}


def dbscan_columns(Xd, minpts=5, eps=0.03, energy_frac=0.06, parallel_thr=0.995):
    th, mag, _ = u.ssp_angles(Xd, energy_frac=energy_frac, parallel_thr=parallel_thr)
    if th.size == 0:
        return np.zeros((2, 0)), th
    P = np.vstack([np.cos(th), np.sin(th)]).T
    lab = DBSCAN(eps=eps, min_samples=minpts).fit_predict(P)
    ang = []
    for l in sorted(set(lab)):
        if l == -1:
            continue
        m = lab == l
        ang.append(np.arctan2(np.mean(np.sin(th[m])), np.mean(np.cos(th[m]))))
    ang = np.sort(ang)
    cols = np.vstack([np.cos(ang), np.sin(ang)]) if len(ang) else np.zeros((2, 0))
    return cols, th


# ============================================================================
print("[1/9] time-domain sources & mixtures ...")
x_clean = u.mix(S, A)
fig, ax = plt.subplots(1, 3, figsize=(7.0, 1.7))
seg = slice(0, 400)
for i in range(3):
    ax[i].plot(T[seg], S[i][seg], color=C["src"])
    ax[i].set_title(f"Source $s_{i+1}(t)$")
    ax[i].set_xlabel("Time (s)")
    ax[i].set_ylim(-3.2, 3.2)
ax[0].set_ylabel("Amplitude")
fig.tight_layout()
fig.savefig(os.path.join(FIG, "fig_time_sources.pdf"))
plt.close(fig)

fig, ax = plt.subplots(1, 2, figsize=(4.7, 1.7))
for i in range(2):
    ax[i].plot(T[seg], x_clean[i][seg], color=C["mix"])
    ax[i].set_title(f"Observation $x_{i+1}(t)$")
    ax[i].set_xlabel("Time (s)")
ax[0].set_ylabel("Amplitude")
fig.tight_layout()
fig.savefig(os.path.join(FIG, "fig_time_mixtures.pdf"))
plt.close(fig)

# ============================================================================
print("[2/9] sparse spectra ...")
X = u.to_spectrum(x_clean)
Ssp = u.to_spectrum(S)
freq = np.arange(N) / N * FS
fmask = freq <= 260
fig, ax = plt.subplots(2, 3, figsize=(7.0, 3.0))
for i in range(3):
    ax[0, i].plot(freq[fmask], np.abs(Ssp[i][fmask]) * 2 / N, color=C["src"])
    ax[0, i].set_title(f"Source spectrum $|S_{i+1}(f)|$")
    ax[0, i].set_xlim(0, 260)
for i in range(2):
    ax[1, i].plot(freq[fmask], np.abs(X[i][fmask]) * 2 / N, color=C["mix"])
    ax[1, i].set_title(f"Observation spectrum $|X_{i+1}(f)|$")
    ax[1, i].set_xlabel("Frequency (Hz)")
    ax[1, i].set_xlim(0, 260)
ax[1, 2].axis("off")
ax[0, 0].set_ylabel("Magnitude")
ax[1, 0].set_ylabel("Magnitude")
fig.tight_layout()
fig.savefig(os.path.join(FIG, "fig_freq_spectra.pdf"))
plt.close(fig)

# ============================================================================
print("[3/9] dilation-erosion illustration ...")
demo = np.zeros(11); demo[5] = 10.0
demoD = np.convolve(demo, np.ones(3) / 3, mode="same")
demoE = u._erode_1d(demoD, 3)
fig, ax = plt.subplots(1, 3, figsize=(7.0, 1.8), sharey=True)
xk = np.arange(11)
for a_, y_, ttl, col in zip(ax, [demo, demoD, demoE],
                            ["Original line $S_1$",
                             "After dilation $D_3\\{S_1\\}$",
                             "After erosion $E_3 D_3\\{S_1\\}$"],
                            [C["src"], C["b"], C["rec"]]):
    a_.stem(xk, y_, linefmt=col, markerfmt="o", basefmt=" ")
    a_.set_title(ttl); a_.set_xlabel("Sample index")
ax[0].set_ylabel("Amplitude")
fig.tight_layout()
fig.savefig(os.path.join(FIG, "fig_dilation_erosion.pdf"))
plt.close(fig)
results["erosion_demo_max_abs_error"] = float(np.max(np.abs(demoE - demo)))

# erosion exactness on the actual spectra
Xd_clean = u.dilate(X, W)
Xe_clean = u.erode(Xd_clean, W)
results["erosion_spectrum_max_abs_error"] = float(np.max(np.abs(Xe_clean - X)))

# ============================================================================
print("[4/9] SSP multiplicity & density (w=1 vs w=%d) ..." % W)
fig, ax = plt.subplots(2, 2, figsize=(7.0, 4.2))
for col, w in enumerate([1, W]):
    Xd = u.dilate(X, w)
    th, mag, keep = u.ssp_angles(Xd, energy_frac=0.06, parallel_thr=0.995)
    binf = keep / N * FS
    # top: SSP angle vs frequency bin (isolated points -> short plateaus)
    ax[0, col].scatter(binf, np.degrees(th), s=12, color=C["a"], alpha=0.75)
    for a0 in TRUE_ANG:
        ax[0, col].axhline(a0, color=C["grey"], ls="--", lw=0.6)
    ax[0, col].set_title(f"SSP directions, $w={w}$  ({th.size} points)")
    ax[0, col].set_xlabel("Frequency (Hz)")
    ax[0, col].set_ylabel("Direction angle (deg)")
    ax[0, col].set_xlim(0, 260); ax[0, col].set_ylim(0, 90)
    # bottom: angle histogram with raw counts
    ax[1, col].hist(np.degrees(th), bins=np.arange(0, 91, 1.5),
                    color=C["a"], alpha=0.85)
    for a0 in TRUE_ANG:
        ax[1, col].axvline(a0, color=C["grey"], ls="--", lw=0.6)
    ax[1, col].set_title(f"Direction histogram, $w={w}$")
    ax[1, col].set_xlabel("Direction angle (deg)")
    ax[1, col].set_ylabel("SSP count")
    ax[1, col].set_xlim(0, 90)
fig.tight_layout()
fig.savefig(os.path.join(FIG, "fig_scatter_density.pdf"))
plt.close(fig)

# ============================================================================
print("[5/9] DBSCAN clustering (w=1 vs w=%d) ..." % W)
fig, ax = plt.subplots(1, 2, figsize=(7.0, 3.0))
for col, w in enumerate([1, W]):
    Xd = u.dilate(X, w)
    th, mag, _ = u.ssp_angles(Xd, energy_frac=0.06, parallel_thr=0.995)
    Pt = np.vstack([np.cos(th), np.sin(th)]).T
    lab = DBSCAN(eps=0.03, min_samples=5).fit_predict(Pt)
    palette = {0: C["a"], 1: C["b"], 2: C["c"]}
    for l in sorted(set(lab)):
        m = lab == l
        cc = "#adb5bd" if l == -1 else palette.get(l, "#000")
        lbl = "noise" if l == -1 else f"cluster {l+1}"
        ax[col].scatter(Pt[m, 0], Pt[m, 1], s=18, color=cc, label=lbl, alpha=0.8)
    n_found = len(set(lab) - {-1})
    ax[col].set_title(f"$w={w}$: {n_found} cluster(s) found")
    ax[col].set_xlabel("$\\cos\\theta$"); ax[col].set_ylabel("$\\sin\\theta$")
    ax[col].set_xlim(0, 1.05); ax[col].set_ylim(0, 1.05)
    ax[col].legend(loc="lower left", framealpha=0.9)
fig.tight_layout()
fig.savefig(os.path.join(FIG, "fig_dbscan.pdf"))
plt.close(fig)

# ============================================================================
print("[6/9] DBSCAN robustness vs SNR (headline) ...")
snr_list = [30, 27, 24, 21, 18, 15]
rob = {"snr": snr_list, "succ_nodil": [], "succ_dil": [],
       "rmse_nodil": [], "rmse_dil": [], "npts_nodil": [], "npts_dil": []}
truth = np.sort(TRUE_ANG)
REPS = 100
for snr in snr_list:
    s0 = s1 = 0; r0 = []; r1 = []; n0 = []; n1 = []
    for tr in range(REPS):
        xn = u.mix(S, A, snr_db=snr, seed=10000 + tr)
        Xn = u.to_spectrum(xn)
        c0, th0 = dbscan_columns(Xn, minpts=5)
        c1, th1 = dbscan_columns(u.dilate(Xn, W), minpts=5)
        n0.append(th0.size); n1.append(th1.size)
        if c0.shape[1] == 3:
            s0 += 1
            r0.append(np.sqrt(np.mean((np.sort(np.degrees(np.arctan2(c0[1], c0[0]))) - truth) ** 2)))
        if c1.shape[1] == 3:
            s1 += 1
            r1.append(np.sqrt(np.mean((np.sort(np.degrees(np.arctan2(c1[1], c1[0]))) - truth) ** 2)))
    rob["succ_nodil"].append(100 * s0 / REPS)
    rob["succ_dil"].append(100 * s1 / REPS)
    rob["rmse_nodil"].append(float(np.mean(r0)) if r0 else float("nan"))
    rob["rmse_dil"].append(float(np.mean(r1)) if r1 else float("nan"))
    rob["npts_nodil"].append(float(np.mean(n0)))
    rob["npts_dil"].append(float(np.mean(n1)))
results["dbscan_robustness"] = rob

fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.7))
ax[0].plot(snr_list, rob["succ_nodil"], "o-", color=C["grey"], label="without dilation ($w=1$)")
ax[0].plot(snr_list, rob["succ_dil"], "s-", color=C["rec"], label=f"with dilation ($w={W}$)")
ax[0].set_xlabel("SNR (dB)"); ax[0].set_ylabel("Correct-detection rate (%)")
ax[0].set_title("Mixing-matrix estimation success"); ax[0].set_ylim(-5, 105)
ax[0].legend(); ax[0].invert_xaxis()
ax[1].plot(snr_list, rob["rmse_dil"], "s-", color=C["rec"], label=f"with dilation ($w={W}$)")
ax[1].set_xlabel("SNR (dB)"); ax[1].set_ylabel("Direction RMSE (deg)")
ax[1].set_title("Estimated-direction accuracy (dilation)")
ax[1].legend(); ax[1].invert_xaxis()
fig.tight_layout()
fig.savefig(os.path.join(FIG, "fig_robust_dbscan.pdf"))
plt.close(fig)

# ============================================================================
print("[7/9] window-length & minPts sweep ...")
w_list = [1, 3, 5, 7, 9, 11, 15, 21]
sweep = {"w": w_list, "npts": [], "succ": []}
REPS_W = 60
for w in w_list:
    npts = []; succ = 0
    for tr in range(REPS_W):
        xn = u.mix(S, A, snr_db=20, seed=12000 + tr)
        Xd = u.dilate(u.to_spectrum(xn), w)
        c, th = dbscan_columns(Xd, minpts=5)
        npts.append(th.size)
        if c.shape[1] == 3:
            succ += 1
    sweep["npts"].append(float(np.mean(npts)))
    sweep["succ"].append(100 * succ / REPS_W)
results["window_sweep"] = sweep

fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.7))
ax[0].plot(w_list, sweep["npts"], "o-", color=C["a"])
ax[0].set_xlabel("Dilation window length $w$")
ax[0].set_ylabel("Number of SSPs")
ax[0].set_title("SSP density vs window length")
ax[1].plot(w_list, sweep["succ"], "s-", color=C["rec"])
ax[1].set_xlabel("Dilation window length $w$")
ax[1].set_ylabel("Correct-detection rate (%)")
ax[1].set_title("Estimation success vs window (SNR = 20 dB)")
ax[1].set_ylim(-5, 105)
fig.tight_layout()
fig.savefig(os.path.join(FIG, "fig_window_sweep.pdf"))
plt.close(fig)

# ============================================================================
print("[8/9] end-to-end separation & correlation vs SNR ...")
snr_e2e = [None, 30, 25, 20]
e2e = {"snr": [], "mean_corr": [], "per_src": [], "sdr": []}
per_src_last = None; rec_for_plot = None; est_cols_noiseless = None
for snr in snr_e2e:
    mcs = []; pers = []; sdrs = []
    reps = 1 if snr is None else 10
    for tr in range(reps):
        xn = u.mix(S, A, snr_db=snr, seed=13000 + tr) if snr else u.mix(S, A)
        Xn = u.to_spectrum(xn)
        Xd = u.dilate(Xn, W)
        cols, _ = dbscan_columns(Xd, minpts=5)
        if cols.shape[1] != 3:
            continue
        Sd = u.recover_sources(Xd, cols, energy_frac=0.02)
        Se = u.erode(Sd, W)
        rec = u.from_spectrum(Se)
        mc, per, perm, sdr = u.match_and_score(S, rec)
        mcs.append(mc); pers.append(per[np.argsort(perm)] if False else per); sdrs.append(sdr)
        if snr is None:
            rec_for_plot = (rec, perm)
            est_cols_noiseless = cols
    e2e["snr"].append("inf" if snr is None else snr)
    e2e["mean_corr"].append(float(np.mean(mcs)))
    e2e["per_src"].append(np.mean(pers, axis=0).tolist())
    e2e["sdr"].append(np.mean(sdrs, axis=0).tolist())
results["end_to_end"] = e2e

# recovered-vs-true time figure (noiseless)
rec, perm = rec_for_plot
fig, ax = plt.subplots(1, 3, figsize=(7.0, 1.8))
seg = slice(0, 400)
for i in range(3):
    j = perm[i]
    a = rec[j]; alpha = np.dot(S[i], a) / (np.dot(a, a) + 1e-30)
    ax[i].plot(T[seg], S[i][seg], color=C["src"], label="true")
    ax[i].plot(T[seg], (alpha * a)[seg], color=C["rec"], ls="--", label="recovered")
    ax[i].set_title(f"Source $s_{i+1}(t)$")
    ax[i].set_xlabel("Time (s)")
ax[0].set_ylabel("Amplitude")
ax[0].legend(loc="upper right", ncol=1)
fig.tight_layout()
fig.savefig(os.path.join(FIG, "fig_recovered_time.pdf"))
plt.close(fig)

# mixing-matrix table (noiseless)
est_ang = np.sort(np.degrees(np.arctan2(est_cols_noiseless[1], est_cols_noiseless[0])))
results["mixing_table"] = {
    "true_angle_deg": np.sort(TRUE_ANG).tolist(),
    "est_angle_deg": est_ang.tolist(),
    "true_cols_unit": (A / np.linalg.norm(A, axis=0)).tolist(),
}

# correlation vs SNR figure
fig, ax = plt.subplots(figsize=(3.5, 2.6))
xs = [40 if v == "inf" else v for v in e2e["snr"]]
ax.plot(xs, e2e["mean_corr"], "o-", color=C["rec"])
ax.set_xlabel("SNR (dB)   [40 = noiseless]")
ax.set_ylabel("Mean correlation coefficient")
ax.set_title("End-to-end separation quality")
ax.set_ylim(0.9, 1.005); ax.grid(alpha=0.3)
fig.tight_layout()
fig.savefig(os.path.join(FIG, "fig_corr_snr.pdf"))
plt.close(fig)

# ============================================================================
print("[9/9] writing results ...")
with open(os.path.join(RES, "results.json"), "w") as f:
    json.dump(results, f, indent=2)

print("\n==== KEY RESULTS ====")
print("erosion demo max |err|     :", results["erosion_demo_max_abs_error"])
print("erosion spectrum max |err| :", results["erosion_spectrum_max_abs_error"])
print("mixing true angles (deg)   :", np.round(results["mixing_table"]["true_angle_deg"], 4))
print("mixing est  angles (deg)   :", np.round(results["mixing_table"]["est_angle_deg"], 4))
print("DBSCAN success nodil (%)   :", rob["succ_nodil"])
print("DBSCAN success dil   (%)   :", rob["succ_dil"])
print("DBSCAN dir RMSE dil (deg)  :", np.round(rob["rmse_dil"], 3))
print("end-to-end SNR             :", e2e["snr"])
print("end-to-end mean corr       :", np.round(e2e["mean_corr"], 5))
print("done.")
