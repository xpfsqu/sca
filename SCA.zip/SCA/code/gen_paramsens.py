"""gen_paramsens.py -- DBSCAN parameter sensitivity grid (param_sens.json,
Table paramsens). Correct-detection rate vs (eps, minPts) at 20 dB with w = 9."""
import json, os, numpy as np
from sklearn.cluster import DBSCAN
import ubss_dilation as u

RES = os.path.join(os.path.dirname(__file__), "..", "results")
os.makedirs(RES, exist_ok=True)

rng = np.random.default_rng(7)
ph = rng.uniform(0, 2 * np.pi, size=(3, 3))
AMPS = np.array([[1.0, 0.55, 0.80], [1.0, 0.65, 0.45], [0.90, 0.60, 1.0]])
s, _ = u.generate_sources(n=10000, fs=1000.0, amps=AMPS, phases=ph)
A = u.DEFAULT_A


def succ(eps, mp, w=9, snr=20, reps=50):
    c = 0
    for tr in range(reps):
        xn = u.mix(s, A, snr_db=snr, seed=60000 + tr)
        Xd = u.dilate(u.to_spectrum(xn), w)
        th, _, _ = u.ssp_angles(Xd, energy_frac=0.06, parallel_thr=0.995)
        if th.size == 0:
            continue
        P = np.vstack([np.cos(th), np.sin(th)]).T
        lab = DBSCAN(eps=eps, min_samples=mp).fit_predict(P)
        c += (len(set(lab) - {-1}) == 3)
    return 100 * c / reps


grid = {}
print("eps \\ minPts   3     5     8")
for eps in [0.02, 0.03, 0.05, 0.08]:
    row = [succ(eps, mp) for mp in [3, 5, 8]]
    grid[f"{eps:.2f}"] = row
    print(f"{eps:.2f}        " + "  ".join(f"{v:4.0f}%" for v in row))
json.dump(grid, open(os.path.join(RES, "param_sens.json"), "w"), indent=2)
print("saved param_sens.json")
