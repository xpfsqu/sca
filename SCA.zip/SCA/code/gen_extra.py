"""Supplementary experiments and figures: variance-vs-window, scatter-cone
geometry, and a harder 4-source/2-sensor scenario."""
import json, os, numpy as np
import matplotlib as mpl; mpl.use("Agg")
import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
import ubss_dilation as u

FIG = os.path.join(os.path.dirname(__file__), "..", "figures")
RES = os.path.join(os.path.dirname(__file__), "..", "results")
plt.rcParams.update({"font.family": "serif", "font.size": 9, "axes.titlesize": 9,
    "axes.labelsize": 9, "legend.fontsize": 8, "xtick.labelsize": 8,
    "ytick.labelsize": 8, "lines.linewidth": 1.0, "axes.linewidth": 0.6,
    "figure.dpi": 150, "savefig.bbox": "tight", "savefig.pad_inches": 0.02})
C = {"a": "#1f4e79", "b": "#2a9d8f", "c": "#e76f51", "d": "#8338ec",
     "rec": "#c1121f", "grey": "#6c757d"}
extra = {}

# ---------------------------------------------------------------- variance vs w
print("variance vs window ...")
fs, N, f0 = 1000.0, 10000, 100.0
tt = np.arange(N) / fs
a = np.array([0.5, 0.8]); true = np.degrees(np.arctan2(a[1], a[0]))
wlist = [1, 3, 5, 7, 9, 11, 15, 21]
snrs = [30, 20]
fig, ax = plt.subplots(figsize=(3.5, 2.6))
for snr, mk in zip(snrs, ["o-", "s-"]):
    stds = []
    for w in wlist:
        errs = []
        for tr in range(400):
            rng = np.random.default_rng(20000 + tr)
            s = np.cos(2 * np.pi * f0 * tt + rng.uniform(0, 2 * np.pi))
            x = np.vstack([a[0] * s, a[1] * s])
            p = np.mean(x ** 2, 1, keepdims=True) * 10 ** (-snr / 10)
            x = x + rng.normal(0, np.sqrt(p), x.shape)
            X = u.to_spectrum(x); k = int(round(f0 * N / fs))
            Xd = u.dilate(X, w) if w > 1 else X
            m = (w - 1) // 2
            idx = np.arange(k - m, k + m + 1)
            ang = np.degrees(np.arctan2(np.abs(Xd[1, idx]), np.abs(Xd[0, idx])))
            errs.append(np.mean(ang) - true)
        stds.append(np.std(errs))
    ax.plot(wlist, stds, mk, label=f"SNR = {snr} dB",
            color=C["a"] if snr == 30 else C["rec"])
ax.set_xlabel("Dilation window $w$"); ax.set_ylabel("Direction-estimate std (deg)")
ax.set_title("Accuracy cost of dilation (single line)")
ax.legend(); ax.grid(alpha=0.3)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig_variance_w.pdf")); plt.close(fig)

# ---------------------------------------------------------------- scatter cones
print("scatter cones ...")
rng = np.random.default_rng(7); ph = rng.uniform(0, 2 * np.pi, size=(3, 3))
AMPS = np.array([[1.0, 0.55, 0.80], [1.0, 0.65, 0.45], [0.90, 0.60, 1.0]])
S, T = u.generate_sources(n=10000, fs=1000.0, amps=AMPS, phases=ph)
A = u.DEFAULT_A
x = u.mix(S, A, snr_db=20, seed=1)
X = u.to_spectrum(x)
mag = np.sqrt(np.abs(X[0]) ** 2 + np.abs(X[1]) ** 2)
sel = np.where(mag > 0.02 * mag.max())[0]
sel = sel[sel < N // 2]
fig, ax = plt.subplots(figsize=(3.5, 3.1))
ax.scatter(np.real(X[0][sel]), np.real(X[1][sel]), s=8, color=C["grey"],
           alpha=0.5, label="active atoms")
Au = A / np.linalg.norm(A, axis=0)
L = 1.15 * np.max(np.abs(np.real(X[0][sel])))
cols = [C["a"], C["b"], C["c"]]
for j in range(3):
    ax.plot([-L * Au[0, j], L * Au[0, j]], [-L * Au[1, j], L * Au[1, j]],
            color=cols[j], lw=1.4, label=f"column $a_{j+1}$")
ax.set_xlabel("$\\mathrm{Re}\\,X_1(k)$"); ax.set_ylabel("$\\mathrm{Re}\\,X_2(k)$")
ax.set_title("Observation scatter aligns with mixing columns")
ax.legend(fontsize=7, loc="upper left"); ax.set_aspect("equal", "box")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig_cones.pdf")); plt.close(fig)

# ---------------------------------------------------- harder 4-source scenario
print("4-source/2-sensor scenario ...")
FREQ4 = np.array([[100.0, 220.0, 50.0], [10.0, 130.0, 170.0],
                  [160.0, 190.0, 80.0], [40.0, 110.0, 205.0]])
ph4 = rng.uniform(0, 2 * np.pi, size=FREQ4.shape)
amp4 = np.array([[1.0, 0.6, 0.8], [1.0, 0.7, 0.5], [0.9, 0.6, 1.0], [0.8, 1.0, 0.6]])
S4, _ = u.generate_sources(FREQ4, n=10000, fs=1000.0, amps=amp4, phases=ph4)
# 2 x 4 mixing with 4 reasonably separated directions
ang4 = np.deg2rad([12.0, 34.0, 55.0, 74.0])
A4 = np.vstack([np.cos(ang4), np.sin(ang4)])
truth4 = np.sort(np.degrees(ang4))

def dbscan_cols(Xd, minpts=5, eps=0.03):
    th, _, _ = u.ssp_angles(Xd, energy_frac=0.06, parallel_thr=0.995)
    if th.size == 0:
        return np.zeros((2, 0)), th
    P = np.vstack([np.cos(th), np.sin(th)]).T
    lab = DBSCAN(eps=eps, min_samples=minpts).fit_predict(P)
    ang = [np.arctan2(np.mean(np.sin(th[lab == l])), np.mean(np.cos(th[lab == l])))
           for l in sorted(set(lab)) if l != -1]
    ang = np.sort(ang)
    return (np.vstack([np.cos(ang), np.sin(ang)]) if len(ang) else np.zeros((2, 0))), th

snr4 = [30, 25, 20, 15]
sc = {"snr": snr4, "succ_nodil": [], "succ_dil": [], "rmse_dil": [], "corr_dil": []}
for snr in snr4:
    s0 = s1 = 0; r1 = []; cc = []
    for tr in range(60):
        xn = u.mix(S4, A4, snr_db=snr, seed=30000 + tr); Xn = u.to_spectrum(xn)
        c0, _ = dbscan_cols(Xn); c1, _ = dbscan_cols(u.dilate(Xn, 9))
        if c0.shape[1] == 4:
            s0 += 1
        if c1.shape[1] == 4:
            s1 += 1
            r1.append(np.sqrt(np.mean((np.sort(np.degrees(np.arctan2(c1[1], c1[0]))) - truth4) ** 2)))
            if tr < 12:  # a few full separations for correlation
                Sd = u.recover_sources(u.dilate(Xn, 9), c1, energy_frac=0.02)
                rec = u.from_spectrum(u.erode(Sd, 9))
                mc, _, _, _ = u.match_and_score(S4, rec); cc.append(mc)
    sc["succ_nodil"].append(100 * s0 / 60); sc["succ_dil"].append(100 * s1 / 60)
    sc["rmse_dil"].append(float(np.mean(r1)) if r1 else float("nan"))
    sc["corr_dil"].append(float(np.mean(cc)) if cc else float("nan"))
    print(f"  SNR {snr}: succ nodil {sc['succ_nodil'][-1]:.0f}%  dil {sc['succ_dil'][-1]:.0f}%  "
          f"rmse {sc['rmse_dil'][-1]:.3f}  corr {sc['corr_dil'][-1]:.4f}")
extra["four_source"] = sc

# DBSCAN scatter figure for n=4 (w=1 vs w=9)
x = u.mix(S4, A4); X = u.to_spectrum(x)
fig, ax = plt.subplots(1, 2, figsize=(7.0, 3.0))
for col, w in enumerate([1, 9]):
    Xd = u.dilate(X, w)
    th, _, _ = u.ssp_angles(Xd, energy_frac=0.06, parallel_thr=0.995)
    P = np.vstack([np.cos(th), np.sin(th)]).T
    lab = DBSCAN(eps=0.03, min_samples=5).fit_predict(P)
    pal = {0: C["a"], 1: C["b"], 2: C["c"], 3: C["d"]}
    for l in sorted(set(lab)):
        m = lab == l
        cc2 = "#adb5bd" if l == -1 else pal.get(l, "#000")
        lb = "noise" if l == -1 else f"cluster {l+1}"
        ax[col].scatter(P[m, 0], P[m, 1], s=16, color=cc2, label=lb, alpha=0.8)
    nf = len(set(lab) - {-1})
    ax[col].set_title(f"$n=4$, $w={w}$: {nf} cluster(s)")
    ax[col].set_xlabel("$\\cos\\theta$"); ax[col].set_ylabel("$\\sin\\theta$")
    ax[col].set_xlim(0, 1.05); ax[col].set_ylim(0, 1.05); ax[col].legend(fontsize=7, loc="lower left")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig_four_source.pdf")); plt.close(fig)

json.dump(extra, open(os.path.join(RES, "extra.json"), "w"), indent=2)
print("done.")
