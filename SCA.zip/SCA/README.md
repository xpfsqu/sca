# DE-SCA-UBSS — reproduction code

Reference implementation for the paper

> **A dilation–erosion sparse component analysis framework for underdetermined
> blind source separation of non-sparse signals under sensor-deficient
> measurement** — Yinjie Jia, Pengfei Xu (School of Information Engineering,
> Suqian University).

The code reproduces **every figure, table and numerical value** in the paper: a
lossless **dilation–erosion** pre/post-processing that makes density-based sparse
component analysis (SCA) work on *over-sparse* transform representations, enabling
underdetermined blind source separation (UBSS) from fewer sensors than sources.

## Method in one paragraph

1. `Φ` — sparsify the observations (here the DFT; any wavelet / time–frequency
   transform works).
2. `D_w` — **dilate** (normalized moving average) to broaden isolated atoms into
   plateaus. This *commutes with the mixing matrix* (Prop. 1) and *multiplies the
   single-source points* (Prop. 2), so density-based clustering becomes reliable.
3. Estimate the mixing matrix and source count by SSP detection (Reju parallelism
   test) + **DBSCAN** on the unit-circle scatter.
4. Recover the sources by per-atom `ℓ1` minimisation (basis pursuit).
5. `E_w` — **erode** (exact inverse of `D_w`, Prop. 3) to restore sharp atoms.
6. `Φ⁻¹` — inverse transform back to the time domain.

Headline result: density-based mixing-matrix estimation succeeds **100 %** with
dilation versus **0 %** without it; two sensors recover three (and four) sources
with near-unity correlation.

## Requirements

```
python >= 3.9
numpy, scipy, scikit-learn, matplotlib
```
Install: `pip install -r requirements.txt`.
(Building the pipeline diagram `fig_flow.pdf` additionally needs a LaTeX
installation with `pdflatex`; all other figures are pure Python.)

## Reproduce everything

```bash
cd code
python run_experiments.py    # main figures + results/results.json
python backend_compare.py    # results/backend_compare.json
python gen_extra.py          # variance-vs-window, cones, 4-source
python gen_realistic.py      # realistic (non-tonal) machinery signals
python gen_sparsity.py       # atoms-per-source sweep
python gen_resolution.py     # angular resolution
python gen_paramsens.py      # DBSCAN parameter grid
python gen_timing.py         # runtime scaling
bash  make_flow.sh           # pipeline diagram (needs pdflatex)
```
or simply `bash run_all.sh`. All randomness is seeded, so the numbers match the
paper. Figures are written to `../figures/`, numeric dumps to `../results/`.

## Files

```
ubss_dilation.py    core library: signal model, D_w / E_w, SSP detection,
                    DBSCAN estimation, l1 recovery, metrics, separate()
run_experiments.py  main benchmark: spectra, dilation/erosion, SSP scatter,
                    DBSCAN, robustness, window sweep, recovery, correlation
backend_compare.py  k-means (1/10 init) vs DBSCAN comparison
gen_extra.py        variance-vs-window, observation cones, 4-source/2-sensor
gen_realistic.py    gear + bearing + unbalance non-tonal validation
gen_sparsity.py     detection rate vs atoms-per-source L
gen_resolution.py   detection rate vs angular gap between columns
gen_paramsens.py    detection rate vs (eps, minPts)
gen_timing.py       end-to-end runtime vs record length
make_flow.sh        builds the pipeline diagram fig_flow.pdf (TikZ)
run_all.sh          runs all of the above in order
requirements.txt, LICENSE (MIT)
```

## Script → paper figure/table map

| Script | Figures | Tables / JSON |
|---|---|---|
| `run_experiments.py` | time sources/mixtures, freq spectra, dilation–erosion, SSP scatter+density, DBSCAN, robustness, window sweep, recovered time, corr-vs-SNR | mixing table, end-to-end (`results.json`) |
| `backend_compare.py` | — | back-end comparison (`backend_compare.json`) |
| `gen_extra.py` | variance-vs-window, cones, four-source | four-source (`extra.json`) |
| `gen_realistic.py` | realistic signals | realistic (`realistic.json`) |
| `gen_sparsity.py` | sparsity sweep | `sparsity_sweep.json` |
| `gen_resolution.py` | angular resolution | `resolution.json` |
| `gen_paramsens.py` | — | parameter grid (`param_sens.json`) |
| `gen_timing.py` | runtime | `timing.json` |
| `make_flow.sh` | pipeline diagram (Fig. 1) | — |

## Minimal example

```python
import numpy as np, ubss_dilation as u

phases = np.random.default_rng(7).uniform(0, 2*np.pi, size=(3, 3))
s, t = u.generate_sources(n=10000, fs=1000.0, phases=phases)  # 3 sources
x = u.mix(s, u.DEFAULT_A, snr_db=30)                          # 2 noisy sensors

A_hat, s_hat = u.separate(x, w=9)   # full DE-SCA pipeline; infers the source count
mean_corr, per_src, perm, sdr = u.match_and_score(s, s_hat)
print(A_hat.shape[1], mean_corr)    # 3 sources, corr ≈ 0.999
```

## License

MIT — see `LICENSE`.
