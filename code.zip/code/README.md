# Manuscript package — Dilation–erosion SCA for underdetermined machinery source separation
 

## Contents

code/
  ubss_dilation.py      # core library (operators, estimation, recovery, metrics, separate())
  run_experiments.py    # regenerates the main figures and results
  backend_compare.py    # clustering back-end comparison
  gen_extra.py          # supplementary figures + 4-source scenario
  gen_realistic.py      # realistic (non-tonal) machinery-signal validation
  README.md             # code documentation
  requirements.txt
  LICENSE               # MIT
results/                # JSON dumps of the numerical results
```

## Reproducing the results

```bash
cd code
pip install -r requirements.txt
python run_experiments.py
python backend_compare.py
python gen_extra.py
```

All randomness is seeded; the figures and reported numbers are reproduced exactly.
 
