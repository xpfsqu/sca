# DE-SCA-UBSS

Reference implementation for the paper

> **A dilation–erosion sparse component analysis framework for underdetermined
> blind source separation of non-sparse machinery signals under sensor-deficient
> measurement**
> Yinjie Jia and Pengfei Xu, School of Information Engineering, Suqian University.

The code reproduces every figure, table and numerical result in the manuscript:
a lossless **dilation–erosion** pre/post-processing that makes density-based
sparse component analysis (SCA) work on *over-sparse* transform representations,
enabling underdetermined blind source separation (UBSS) of machinery signals from
fewer sensors than sources.

## What the method does

1. `Φ` — sparsify the observations with the DFT (non-sparse in time → sparse in frequency).
2. `D_w` — **dilate** (normalized moving average) to broaden isolated spectral
   lines into short plateaus. This *commutes with the mixing matrix* and
   *multiplies the single-source points*, so density-based clustering becomes reliable.
3. Estimate the mixing matrix and the number of sources by SSP detection
   (Reju parallelism test) + **DBSCAN** on the unit-circle scatter.
4. Recover the sources by per-atom `ℓ1` minimisation (basis pursuit).
5. `E_w` — **erode** (exact inverse of `D_w`) to restore sharp spectral lines.
6. `Φ⁻¹` — inverse DFT back to the time domain.

Key result: density-based mixing-matrix estimation succeeds **100 %** with
dilation versus **0 %** without it, and two sensors recover three (and four)
sources with near-unity correlation.

## Repository layout

```
code/
  ubss_dilation.py     # core library: signal model, D_w/E_w, SSP, DBSCAN, ℓ1 recovery, metrics
  run_experiments.py   # regenerates the main figures/tables (Figs. 2–13, Tables 2–6)
  backend_compare.py   # clustering back-end comparison (Table 4)
  gen_extra.py         # variance-vs-window, scatter cones, 4-source scenario
  gen_realistic.py     # realistic machinery signals (gear/bearing/unbalance) validation
requirements.txt
LICENSE                # MIT
figures/               # produced PDFs (created on run)
results/               # produced JSON result dumps (created on run)
```

## Requirements

```
python >= 3.9
numpy
scipy
scikit-learn
matplotlib
```

Install with:

```bash
pip install -r requirements.txt
```

## Reproducing the results

```bash
cd code
python run_experiments.py     # main figures + results/results.json
python backend_compare.py     # clustering back-end table
python gen_extra.py           # supplementary figures + 4-source scenario
python gen_realistic.py       # realistic (non-tonal) machinery-signal validation
```

All randomness is seeded, so the numbers match the manuscript. The full
three-source pipeline runs in well under a second per realisation on a commodity
CPU.

## Minimal example

```python
import numpy as np
import ubss_dilation as u

# 3 sources, 2 sensors (underdetermined)
phases = np.random.default_rng(7).uniform(0, 2*np.pi, size=(3, 3))
s, t = u.generate_sources(n=10000, fs=1000.0, phases=phases)
A = u.DEFAULT_A                      # 2 x 3 mixing matrix
x = u.mix(s, A, snr_db=30)           # two noisy observations

# full DE-SCA pipeline: Φ → D_w → DBSCAN estimate → ℓ1 → E_w → Φ⁻¹
A_hat, s_hat = u.separate(x, w=9)    # infers the number of sources too

mean_corr, per_src, perm, sdr = u.match_and_score(s, s_hat)
print(A_hat.shape[1], mean_corr)     # 3 sources, corr ≈ 0.999
```

The individual stages (`to_spectrum`, `dilate`, `estimate_mixing_dbscan`,
`recover_sources`, `erode`, `from_spectrum`) can also be called directly; see
`separate()` in `ubss_dilation.py`.

## Notes on scope

The benchmark uses an instantaneous mixture and tonal (over-sparse) sources,
which is where the sensor-deficiency motivation is sharpest. The dilation–erosion
principle is transform- and clusterer-agnostic; convolutive mixtures can be
handled per-frequency-bin in the STFT domain (future work).

## Citation

If you use this code, please cite the paper (see the manuscript for the full
BibTeX entry).

## License

MIT — see `LICENSE`.
